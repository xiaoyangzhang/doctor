CREATE TRIGGER order_detail_update
AFTER UPDATE ON `order`
FOR EACH ROW
  begin
    if (NEW.state = 2 && OLD.state !=2)
       then update order_detail set type = 1 where oder_id=NEW.ID;
		end if;
 end;
